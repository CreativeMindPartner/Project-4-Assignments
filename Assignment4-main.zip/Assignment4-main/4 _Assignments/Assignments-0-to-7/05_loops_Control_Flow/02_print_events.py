def main():
    count = 20  
    
    for i in range(count):
        print(i * 2, end=" ")  # Print even number with space

if __name__ == '__main__':
    main()