def main():
    for i in range(20):  # Loop 20 times
        print(i * 2, end=" ")  # Print even numbers

if __name__ == '__main__':
    main()