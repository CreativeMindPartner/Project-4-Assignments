def main():

    animal = input("\033[1;3m What's your favorite animal? \033[0m")


    print(f"My favorite animal is also {animal}!")


if __name__ == '__main__':
    main()