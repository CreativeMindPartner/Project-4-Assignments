def main():

    number = float(input("Type a number to see its square: "))
    
    # Calculate the square of the number
    square = number * number
    
    print(f"{number} squared is {square}")



if __name__ == '__main__':
    main()