def main():

# Assigning ages based on the given relationships
    Anton = 21
    Beth = Anton + 6
    Chen = Beth + 20
    Drew = Anton + Chen
    Ethan = Chen

    # Printing the names and ages in the required format
    print(f"Anton is {Anton}")
    print(f"Beth is {Beth}")
    print(f"Chen is {Chen}")
    print(f"Drew is {Drew}")
    print(f"Ethan is {Ethan}")

if __name__ == '__main__':
    main()